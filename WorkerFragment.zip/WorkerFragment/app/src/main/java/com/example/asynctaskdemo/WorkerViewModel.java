package com.example.asynctaskdemo;

import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;
import android.os.AsyncTask;

import java.util.ArrayList;
import java.util.List;

public class WorkerViewModel extends ViewModel {
    private List<Integer> data = new ArrayList<>();
    private AsyncTask<Void, Integer, Void> asyncTask;
    private MutableLiveData<List<Integer>> mutableLiveData = new MutableLiveData<>();

    public MutableLiveData<List<Integer>> getMutableLiveData() {
        return mutableLiveData;
    }

    public void runAsyncTask() {
        asyncTask = new AsyncTaskWorker().execute();
    }


    @Override
    protected void onCleared() {
        super.onCleared();
        asyncTask.cancel(true);
    }

    public class AsyncTaskWorker extends AsyncTask<Void, Integer, Void> {

        @Override
        protected Void doInBackground(Void... voids) {
            int i = 0;
            while (true) {
                try {
                    publishProgress(i++);
                    Thread.sleep(1000);
                    if (isCancelled()) return null;
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

            }
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            super.onProgressUpdate(values);
            data.add(values[0]);
            mutableLiveData.setValue(data);
        }
    }
}


